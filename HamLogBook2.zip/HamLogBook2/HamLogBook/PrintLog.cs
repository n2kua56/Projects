﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace HamLogBook
{
    public partial class PrintLog : Form
    {
        public PrintLog()
        {
            InitializeComponent();
        }
    }
}
