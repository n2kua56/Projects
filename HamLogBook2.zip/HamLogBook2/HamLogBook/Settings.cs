﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace HamLogBook
{
    public partial class Settings : Form
    {
        //TODO: 1) Build AvailableProperties Table
        //TODO: 2) Fill-in/Save Common Fields page
        //TODO: 3) Fill-in/Save List Matches page
        //TODO: 4) Fill-in/Save Alerts Page
        //TODO: 5) Fill-in/Save Fields Display Page
        //TODO: 6) Fill-in/Save Other Titles page
        //TODO: 7) Fill-in/Save Date Options page
        //TODO: 8) Fill-in/Save Call Book Page
        public Settings()
        {
            InitializeComponent();
        }
        
    }
}
