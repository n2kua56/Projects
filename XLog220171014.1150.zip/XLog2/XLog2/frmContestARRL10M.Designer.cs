﻿namespace XLog2
{
    partial class frmContestARRL10M
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.tbPhoneContacts = new System.Windows.Forms.TextBox();
            this.tbTotalContacts = new System.Windows.Forms.TextBox();
            this.tbTotalQSOPoints = new System.Windows.Forms.Label();
            this.tbCWContacts = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbTotalScore = new System.Windows.Forms.TextBox();
            this.tbCWMultipliers = new System.Windows.Forms.TextBox();
            this.tbPhoneMultipliers = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tbTotalMultipliers = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.lblZAC = new System.Windows.Forms.Label();
            this.lblYUC = new System.Windows.Forms.Label();
            this.lblVER = new System.Windows.Forms.Label();
            this.lblTLX = new System.Windows.Forms.Label();
            this.lblTAM = new System.Windows.Forms.Label();
            this.lblTAB = new System.Windows.Forms.Label();
            this.lblSON = new System.Windows.Forms.Label();
            this.lblSIN = new System.Windows.Forms.Label();
            this.lblSLP = new System.Windows.Forms.Label();
            this.lblQUI = new System.Windows.Forms.Label();
            this.lblQRO = new System.Windows.Forms.Label();
            this.lblPUE = new System.Windows.Forms.Label();
            this.lblOAX = new System.Windows.Forms.Label();
            this.lblNLE = new System.Windows.Forms.Label();
            this.lblNAY = new System.Windows.Forms.Label();
            this.lblMOR = new System.Windows.Forms.Label();
            this.lblMIC = new System.Windows.Forms.Label();
            this.lblJAL = new System.Windows.Forms.Label();
            this.lblHGO = new System.Windows.Forms.Label();
            this.lblGBO = new System.Windows.Forms.Label();
            this.lblGTO = new System.Windows.Forms.Label();
            this.lblEMX = new System.Windows.Forms.Label();
            this.lblDGO = new System.Windows.Forms.Label();
            this.lblCOL = new System.Windows.Forms.Label();
            this.lblCOA = new System.Windows.Forms.Label();
            this.lblCMX = new System.Windows.Forms.Label();
            this.lblCHH = new System.Windows.Forms.Label();
            this.lblCHI = new System.Windows.Forms.Label();
            this.lblCAM = new System.Windows.Forms.Label();
            this.lblBCS = new System.Windows.Forms.Label();
            this.lblBAC = new System.Windows.Forms.Label();
            this.lblAGS = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.lblNU = new System.Windows.Forms.Label();
            this.lblYT = new System.Windows.Forms.Label();
            this.lblNWT = new System.Windows.Forms.Label();
            this.lblBC = new System.Windows.Forms.Label();
            this.lblAB = new System.Windows.Forms.Label();
            this.lblSK = new System.Windows.Forms.Label();
            this.lblMB = new System.Windows.Forms.Label();
            this.lblON = new System.Windows.Forms.Label();
            this.lblQC = new System.Windows.Forms.Label();
            this.lblPEI = new System.Windows.Forms.Label();
            this.lblNS = new System.Windows.Forms.Label();
            this.lblNB = new System.Windows.Forms.Label();
            this.lblLB = new System.Windows.Forms.Label();
            this.lblNF = new System.Windows.Forms.Label();
            this.lblSD = new System.Windows.Forms.Label();
            this.lblNE = new System.Windows.Forms.Label();
            this.lblND = new System.Windows.Forms.Label();
            this.lblMO = new System.Windows.Forms.Label();
            this.lblMN = new System.Windows.Forms.Label();
            this.lblKS = new System.Windows.Forms.Label();
            this.lblIA = new System.Windows.Forms.Label();
            this.lblCO = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.lblWI = new System.Windows.Forms.Label();
            this.lblIN = new System.Windows.Forms.Label();
            this.lblIL = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.lblWV = new System.Windows.Forms.Label();
            this.lblOH = new System.Windows.Forms.Label();
            this.lblMI = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.lblWY = new System.Windows.Forms.Label();
            this.lblWA = new System.Windows.Forms.Label();
            this.lblUT = new System.Windows.Forms.Label();
            this.lblOR = new System.Windows.Forms.Label();
            this.lblAK = new System.Windows.Forms.Label();
            this.lblNV = new System.Windows.Forms.Label();
            this.lblMT = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.lblAZ = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lblHI = new System.Windows.Forms.Label();
            this.lblCA = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.lblTX = new System.Windows.Forms.Label();
            this.lblOK = new System.Windows.Forms.Label();
            this.lblNM = new System.Windows.Forms.Label();
            this.lblMS = new System.Windows.Forms.Label();
            this.lblLA = new System.Windows.Forms.Label();
            this.lblAR = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.lblVA = new System.Windows.Forms.Label();
            this.lblTN = new System.Windows.Forms.Label();
            this.lblSC = new System.Windows.Forms.Label();
            this.lblNC = new System.Windows.Forms.Label();
            this.lblKY = new System.Windows.Forms.Label();
            this.lblGA = new System.Windows.Forms.Label();
            this.lblFL = new System.Windows.Forms.Label();
            this.lblAL = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lblDC = new System.Windows.Forms.Label();
            this.lblPA = new System.Windows.Forms.Label();
            this.lblMD = new System.Windows.Forms.Label();
            this.lblDE = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.lblNJ = new System.Windows.Forms.Label();
            this.lblNY = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.lblVT = new System.Windows.Forms.Label();
            this.lbRI = new System.Windows.Forms.Label();
            this.lblNH = new System.Windows.Forms.Label();
            this.lblME = new System.Windows.Forms.Label();
            this.lblMA = new System.Windows.Forms.Label();
            this.lblCT = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.lblR3 = new System.Windows.Forms.Label();
            this.lblR2 = new System.Windows.Forms.Label();
            this.lblR1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnOnOff = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.tbComment = new System.Windows.Forms.TextBox();
            this.btnSaveUpdate = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.cmbState = new System.Windows.Forms.ComboBox();
            this.tbRSTRcvd = new System.Windows.Forms.MaskedTextBox();
            this.tbRSTSent = new System.Windows.Forms.MaskedTextBox();
            this.tbCall = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label22 = new System.Windows.Forms.Label();
            this.tbTotalTimeOn = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.tbSessionTimeOn = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label29 = new System.Windows.Forms.Label();
            this.cmbMode = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.panel13.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.tbPhoneContacts);
            this.groupBox1.Controls.Add(this.tbTotalContacts);
            this.groupBox1.Controls.Add(this.tbTotalQSOPoints);
            this.groupBox1.Controls.Add(this.tbCWContacts);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(6, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(224, 132);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Contacts";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(141, 98);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(64, 20);
            this.textBox4.TabIndex = 15;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(141, 72);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(64, 20);
            this.textBox3.TabIndex = 14;
            // 
            // tbPhoneContacts
            // 
            this.tbPhoneContacts.Location = new System.Drawing.Point(141, 46);
            this.tbPhoneContacts.Name = "tbPhoneContacts";
            this.tbPhoneContacts.ReadOnly = true;
            this.tbPhoneContacts.Size = new System.Drawing.Size(64, 20);
            this.tbPhoneContacts.TabIndex = 13;
            // 
            // tbTotalContacts
            // 
            this.tbTotalContacts.Location = new System.Drawing.Point(141, 20);
            this.tbTotalContacts.Name = "tbTotalContacts";
            this.tbTotalContacts.ReadOnly = true;
            this.tbTotalContacts.Size = new System.Drawing.Size(64, 20);
            this.tbTotalContacts.TabIndex = 12;
            // 
            // tbTotalQSOPoints
            // 
            this.tbTotalQSOPoints.AutoSize = true;
            this.tbTotalQSOPoints.Location = new System.Drawing.Point(19, 98);
            this.tbTotalQSOPoints.Name = "tbTotalQSOPoints";
            this.tbTotalQSOPoints.Size = new System.Drawing.Size(89, 13);
            this.tbTotalQSOPoints.TabIndex = 11;
            this.tbTotalQSOPoints.Text = "Total QSO Points";
            // 
            // tbCWContacts
            // 
            this.tbCWContacts.AutoSize = true;
            this.tbCWContacts.Location = new System.Drawing.Point(30, 72);
            this.tbCWContacts.Name = "tbCWContacts";
            this.tbCWContacts.Size = new System.Drawing.Size(90, 13);
            this.tbCWContacts.TabIndex = 10;
            this.tbCWContacts.Text = "CW Contacts (x4)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Phone Contacts (x2)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Total Contacts";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbTotalScore);
            this.groupBox2.Controls.Add(this.tbCWMultipliers);
            this.groupBox2.Controls.Add(this.tbPhoneMultipliers);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.tbTotalMultipliers);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(276, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(225, 132);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Multipliers";
            // 
            // tbTotalScore
            // 
            this.tbTotalScore.Location = new System.Drawing.Point(141, 98);
            this.tbTotalScore.Name = "tbTotalScore";
            this.tbTotalScore.ReadOnly = true;
            this.tbTotalScore.Size = new System.Drawing.Size(64, 20);
            this.tbTotalScore.TabIndex = 19;
            // 
            // tbCWMultipliers
            // 
            this.tbCWMultipliers.Location = new System.Drawing.Point(141, 72);
            this.tbCWMultipliers.Name = "tbCWMultipliers";
            this.tbCWMultipliers.ReadOnly = true;
            this.tbCWMultipliers.Size = new System.Drawing.Size(64, 20);
            this.tbCWMultipliers.TabIndex = 18;
            // 
            // tbPhoneMultipliers
            // 
            this.tbPhoneMultipliers.Location = new System.Drawing.Point(141, 46);
            this.tbPhoneMultipliers.Name = "tbPhoneMultipliers";
            this.tbPhoneMultipliers.ReadOnly = true;
            this.tbPhoneMultipliers.Size = new System.Drawing.Size(64, 20);
            this.tbPhoneMultipliers.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(19, 98);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 17);
            this.label8.TabIndex = 16;
            this.label8.Text = "Total Score";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(30, 72);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "CW Multipliers";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Phone Mulipliers";
            // 
            // tbTotalMultipliers
            // 
            this.tbTotalMultipliers.Location = new System.Drawing.Point(141, 20);
            this.tbTotalMultipliers.Name = "tbTotalMultipliers";
            this.tbTotalMultipliers.ReadOnly = true;
            this.tbTotalMultipliers.Size = new System.Drawing.Size(64, 20);
            this.tbTotalMultipliers.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Total Multipliers";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox8);
            this.groupBox3.Controls.Add(this.groupBox7);
            this.groupBox3.Controls.Add(this.groupBox6);
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Location = new System.Drawing.Point(6, 158);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(495, 248);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Sates/Regions";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.lblZAC);
            this.groupBox8.Controls.Add(this.lblYUC);
            this.groupBox8.Controls.Add(this.lblVER);
            this.groupBox8.Controls.Add(this.lblTLX);
            this.groupBox8.Controls.Add(this.lblTAM);
            this.groupBox8.Controls.Add(this.lblTAB);
            this.groupBox8.Controls.Add(this.lblSON);
            this.groupBox8.Controls.Add(this.lblSIN);
            this.groupBox8.Controls.Add(this.lblSLP);
            this.groupBox8.Controls.Add(this.lblQUI);
            this.groupBox8.Controls.Add(this.lblQRO);
            this.groupBox8.Controls.Add(this.lblPUE);
            this.groupBox8.Controls.Add(this.lblOAX);
            this.groupBox8.Controls.Add(this.lblNLE);
            this.groupBox8.Controls.Add(this.lblNAY);
            this.groupBox8.Controls.Add(this.lblMOR);
            this.groupBox8.Controls.Add(this.lblMIC);
            this.groupBox8.Controls.Add(this.lblJAL);
            this.groupBox8.Controls.Add(this.lblHGO);
            this.groupBox8.Controls.Add(this.lblGBO);
            this.groupBox8.Controls.Add(this.lblGTO);
            this.groupBox8.Controls.Add(this.lblEMX);
            this.groupBox8.Controls.Add(this.lblDGO);
            this.groupBox8.Controls.Add(this.lblCOL);
            this.groupBox8.Controls.Add(this.lblCOA);
            this.groupBox8.Controls.Add(this.lblCMX);
            this.groupBox8.Controls.Add(this.lblCHH);
            this.groupBox8.Controls.Add(this.lblCHI);
            this.groupBox8.Controls.Add(this.lblCAM);
            this.groupBox8.Controls.Add(this.lblBCS);
            this.groupBox8.Controls.Add(this.lblBAC);
            this.groupBox8.Controls.Add(this.lblAGS);
            this.groupBox8.Controls.Add(this.panel13);
            this.groupBox8.Location = new System.Drawing.Point(389, 13);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(98, 223);
            this.groupBox8.TabIndex = 57;
            this.groupBox8.TabStop = false;
            // 
            // lblZAC
            // 
            this.lblZAC.Location = new System.Drawing.Point(64, 186);
            this.lblZAC.Name = "lblZAC";
            this.lblZAC.Size = new System.Drawing.Size(33, 11);
            this.lblZAC.TabIndex = 95;
            this.lblZAC.Text = "ZAC";
            this.lblZAC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblYUC
            // 
            this.lblYUC.Location = new System.Drawing.Point(2, 186);
            this.lblYUC.Name = "lblYUC";
            this.lblYUC.Size = new System.Drawing.Size(33, 11);
            this.lblYUC.TabIndex = 93;
            this.lblYUC.Text = "YUC";
            this.lblYUC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblVER
            // 
            this.lblVER.Location = new System.Drawing.Point(64, 171);
            this.lblVER.Name = "lblVER";
            this.lblVER.Size = new System.Drawing.Size(33, 11);
            this.lblVER.TabIndex = 92;
            this.lblVER.Text = "VER";
            this.lblVER.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblTLX
            // 
            this.lblTLX.Location = new System.Drawing.Point(33, 171);
            this.lblTLX.Name = "lblTLX";
            this.lblTLX.Size = new System.Drawing.Size(33, 11);
            this.lblTLX.TabIndex = 91;
            this.lblTLX.Text = "TLX";
            this.lblTLX.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblTAM
            // 
            this.lblTAM.Location = new System.Drawing.Point(2, 171);
            this.lblTAM.Name = "lblTAM";
            this.lblTAM.Size = new System.Drawing.Size(33, 11);
            this.lblTAM.TabIndex = 90;
            this.lblTAM.Text = "TAM";
            this.lblTAM.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblTAB
            // 
            this.lblTAB.Location = new System.Drawing.Point(64, 156);
            this.lblTAB.Name = "lblTAB";
            this.lblTAB.Size = new System.Drawing.Size(33, 11);
            this.lblTAB.TabIndex = 89;
            this.lblTAB.Text = "TAB";
            this.lblTAB.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblSON
            // 
            this.lblSON.Location = new System.Drawing.Point(33, 156);
            this.lblSON.Name = "lblSON";
            this.lblSON.Size = new System.Drawing.Size(33, 11);
            this.lblSON.TabIndex = 88;
            this.lblSON.Text = "SON";
            this.lblSON.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblSIN
            // 
            this.lblSIN.Location = new System.Drawing.Point(2, 156);
            this.lblSIN.Name = "lblSIN";
            this.lblSIN.Size = new System.Drawing.Size(33, 11);
            this.lblSIN.TabIndex = 87;
            this.lblSIN.Text = "SIN";
            this.lblSIN.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblSLP
            // 
            this.lblSLP.Location = new System.Drawing.Point(64, 141);
            this.lblSLP.Name = "lblSLP";
            this.lblSLP.Size = new System.Drawing.Size(33, 11);
            this.lblSLP.TabIndex = 86;
            this.lblSLP.Text = "SLP";
            this.lblSLP.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblQUI
            // 
            this.lblQUI.Location = new System.Drawing.Point(33, 141);
            this.lblQUI.Name = "lblQUI";
            this.lblQUI.Size = new System.Drawing.Size(33, 11);
            this.lblQUI.TabIndex = 85;
            this.lblQUI.Text = "QUI";
            this.lblQUI.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblQRO
            // 
            this.lblQRO.Location = new System.Drawing.Point(2, 141);
            this.lblQRO.Name = "lblQRO";
            this.lblQRO.Size = new System.Drawing.Size(33, 11);
            this.lblQRO.TabIndex = 84;
            this.lblQRO.Text = "QRO";
            this.lblQRO.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblPUE
            // 
            this.lblPUE.Location = new System.Drawing.Point(64, 126);
            this.lblPUE.Name = "lblPUE";
            this.lblPUE.Size = new System.Drawing.Size(33, 11);
            this.lblPUE.TabIndex = 83;
            this.lblPUE.Text = "PUE";
            this.lblPUE.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblOAX
            // 
            this.lblOAX.Location = new System.Drawing.Point(33, 126);
            this.lblOAX.Name = "lblOAX";
            this.lblOAX.Size = new System.Drawing.Size(33, 11);
            this.lblOAX.TabIndex = 82;
            this.lblOAX.Text = "OAX";
            this.lblOAX.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblNLE
            // 
            this.lblNLE.Location = new System.Drawing.Point(2, 126);
            this.lblNLE.Name = "lblNLE";
            this.lblNLE.Size = new System.Drawing.Size(33, 11);
            this.lblNLE.TabIndex = 81;
            this.lblNLE.Text = "NLE";
            this.lblNLE.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblNAY
            // 
            this.lblNAY.Location = new System.Drawing.Point(64, 111);
            this.lblNAY.Name = "lblNAY";
            this.lblNAY.Size = new System.Drawing.Size(33, 11);
            this.lblNAY.TabIndex = 80;
            this.lblNAY.Text = "NAY";
            this.lblNAY.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblMOR
            // 
            this.lblMOR.Location = new System.Drawing.Point(33, 111);
            this.lblMOR.Name = "lblMOR";
            this.lblMOR.Size = new System.Drawing.Size(33, 11);
            this.lblMOR.TabIndex = 79;
            this.lblMOR.Text = "MOR";
            this.lblMOR.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblMIC
            // 
            this.lblMIC.Location = new System.Drawing.Point(2, 111);
            this.lblMIC.Name = "lblMIC";
            this.lblMIC.Size = new System.Drawing.Size(33, 11);
            this.lblMIC.TabIndex = 78;
            this.lblMIC.Text = "MIC";
            this.lblMIC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblJAL
            // 
            this.lblJAL.Location = new System.Drawing.Point(64, 96);
            this.lblJAL.Name = "lblJAL";
            this.lblJAL.Size = new System.Drawing.Size(33, 11);
            this.lblJAL.TabIndex = 77;
            this.lblJAL.Text = "JAL";
            this.lblJAL.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblHGO
            // 
            this.lblHGO.Location = new System.Drawing.Point(33, 96);
            this.lblHGO.Name = "lblHGO";
            this.lblHGO.Size = new System.Drawing.Size(33, 11);
            this.lblHGO.TabIndex = 76;
            this.lblHGO.Text = "HGO";
            this.lblHGO.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblGBO
            // 
            this.lblGBO.Location = new System.Drawing.Point(2, 96);
            this.lblGBO.Name = "lblGBO";
            this.lblGBO.Size = new System.Drawing.Size(33, 11);
            this.lblGBO.TabIndex = 75;
            this.lblGBO.Text = "GRO";
            this.lblGBO.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblGTO
            // 
            this.lblGTO.Location = new System.Drawing.Point(64, 81);
            this.lblGTO.Name = "lblGTO";
            this.lblGTO.Size = new System.Drawing.Size(33, 11);
            this.lblGTO.TabIndex = 74;
            this.lblGTO.Text = "GTO";
            this.lblGTO.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblEMX
            // 
            this.lblEMX.Location = new System.Drawing.Point(33, 81);
            this.lblEMX.Name = "lblEMX";
            this.lblEMX.Size = new System.Drawing.Size(35, 11);
            this.lblEMX.TabIndex = 73;
            this.lblEMX.Text = "EMX";
            this.lblEMX.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblDGO
            // 
            this.lblDGO.Location = new System.Drawing.Point(2, 81);
            this.lblDGO.Name = "lblDGO";
            this.lblDGO.Size = new System.Drawing.Size(33, 11);
            this.lblDGO.TabIndex = 72;
            this.lblDGO.Text = "DGO";
            this.lblDGO.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblCOL
            // 
            this.lblCOL.Location = new System.Drawing.Point(64, 66);
            this.lblCOL.Name = "lblCOL";
            this.lblCOL.Size = new System.Drawing.Size(33, 11);
            this.lblCOL.TabIndex = 71;
            this.lblCOL.Text = "COL";
            this.lblCOL.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblCOA
            // 
            this.lblCOA.Location = new System.Drawing.Point(33, 66);
            this.lblCOA.Name = "lblCOA";
            this.lblCOA.Size = new System.Drawing.Size(33, 11);
            this.lblCOA.TabIndex = 70;
            this.lblCOA.Text = "COA";
            this.lblCOA.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblCMX
            // 
            this.lblCMX.Location = new System.Drawing.Point(2, 66);
            this.lblCMX.Name = "lblCMX";
            this.lblCMX.Size = new System.Drawing.Size(33, 11);
            this.lblCMX.TabIndex = 69;
            this.lblCMX.Text = "CMX";
            this.lblCMX.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblCHH
            // 
            this.lblCHH.Location = new System.Drawing.Point(64, 51);
            this.lblCHH.Name = "lblCHH";
            this.lblCHH.Size = new System.Drawing.Size(33, 11);
            this.lblCHH.TabIndex = 68;
            this.lblCHH.Text = "CHH";
            this.lblCHH.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblCHI
            // 
            this.lblCHI.Location = new System.Drawing.Point(33, 51);
            this.lblCHI.Name = "lblCHI";
            this.lblCHI.Size = new System.Drawing.Size(33, 11);
            this.lblCHI.TabIndex = 67;
            this.lblCHI.Text = "CHI";
            this.lblCHI.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblCAM
            // 
            this.lblCAM.Location = new System.Drawing.Point(2, 51);
            this.lblCAM.Name = "lblCAM";
            this.lblCAM.Size = new System.Drawing.Size(33, 11);
            this.lblCAM.TabIndex = 66;
            this.lblCAM.Text = "CAM";
            this.lblCAM.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblBCS
            // 
            this.lblBCS.Location = new System.Drawing.Point(64, 36);
            this.lblBCS.Name = "lblBCS";
            this.lblBCS.Size = new System.Drawing.Size(33, 11);
            this.lblBCS.TabIndex = 65;
            this.lblBCS.Text = "BCS";
            this.lblBCS.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblBAC
            // 
            this.lblBAC.Location = new System.Drawing.Point(33, 36);
            this.lblBAC.Name = "lblBAC";
            this.lblBAC.Size = new System.Drawing.Size(33, 11);
            this.lblBAC.TabIndex = 64;
            this.lblBAC.Text = "BAC";
            this.lblBAC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblAGS
            // 
            this.lblAGS.Location = new System.Drawing.Point(2, 36);
            this.lblAGS.Name = "lblAGS";
            this.lblAGS.Size = new System.Drawing.Size(33, 11);
            this.lblAGS.TabIndex = 63;
            this.lblAGS.Text = "AGS";
            this.lblAGS.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel13
            // 
            this.panel13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel13.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel13.Controls.Add(this.label17);
            this.panel13.Location = new System.Drawing.Point(7, 12);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(84, 22);
            this.panel13.TabIndex = 54;
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.Location = new System.Drawing.Point(1, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(78, 17);
            this.label17.TabIndex = 0;
            this.label17.Text = "Mexico";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.lblNU);
            this.groupBox7.Controls.Add(this.lblYT);
            this.groupBox7.Controls.Add(this.lblNWT);
            this.groupBox7.Controls.Add(this.lblBC);
            this.groupBox7.Controls.Add(this.lblAB);
            this.groupBox7.Controls.Add(this.lblSK);
            this.groupBox7.Controls.Add(this.lblMB);
            this.groupBox7.Controls.Add(this.lblON);
            this.groupBox7.Controls.Add(this.lblQC);
            this.groupBox7.Controls.Add(this.lblPEI);
            this.groupBox7.Controls.Add(this.lblNS);
            this.groupBox7.Controls.Add(this.lblNB);
            this.groupBox7.Controls.Add(this.lblLB);
            this.groupBox7.Controls.Add(this.lblNF);
            this.groupBox7.Controls.Add(this.lblSD);
            this.groupBox7.Controls.Add(this.lblNE);
            this.groupBox7.Controls.Add(this.lblND);
            this.groupBox7.Controls.Add(this.lblMO);
            this.groupBox7.Controls.Add(this.lblMN);
            this.groupBox7.Controls.Add(this.lblKS);
            this.groupBox7.Controls.Add(this.lblIA);
            this.groupBox7.Controls.Add(this.lblCO);
            this.groupBox7.Controls.Add(this.panel12);
            this.groupBox7.Controls.Add(this.panel11);
            this.groupBox7.Location = new System.Drawing.Point(293, 13);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(97, 223);
            this.groupBox7.TabIndex = 56;
            this.groupBox7.TabStop = false;
            // 
            // lblNU
            // 
            this.lblNU.Location = new System.Drawing.Point(64, 173);
            this.lblNU.Name = "lblNU";
            this.lblNU.Size = new System.Drawing.Size(33, 11);
            this.lblNU.TabIndex = 86;
            this.lblNU.Text = "NU";
            this.lblNU.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblYT
            // 
            this.lblYT.Location = new System.Drawing.Point(2, 173);
            this.lblYT.Name = "lblYT";
            this.lblYT.Size = new System.Drawing.Size(33, 11);
            this.lblYT.TabIndex = 84;
            this.lblYT.Text = "YT";
            this.lblYT.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblNWT
            // 
            this.lblNWT.Location = new System.Drawing.Point(64, 158);
            this.lblNWT.Name = "lblNWT";
            this.lblNWT.Size = new System.Drawing.Size(33, 11);
            this.lblNWT.TabIndex = 83;
            this.lblNWT.Text = "NWT";
            this.lblNWT.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblBC
            // 
            this.lblBC.Location = new System.Drawing.Point(33, 158);
            this.lblBC.Name = "lblBC";
            this.lblBC.Size = new System.Drawing.Size(33, 11);
            this.lblBC.TabIndex = 82;
            this.lblBC.Text = "BC";
            this.lblBC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblAB
            // 
            this.lblAB.Location = new System.Drawing.Point(2, 158);
            this.lblAB.Name = "lblAB";
            this.lblAB.Size = new System.Drawing.Size(33, 11);
            this.lblAB.TabIndex = 81;
            this.lblAB.Text = "AB";
            this.lblAB.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblSK
            // 
            this.lblSK.Location = new System.Drawing.Point(64, 143);
            this.lblSK.Name = "lblSK";
            this.lblSK.Size = new System.Drawing.Size(33, 11);
            this.lblSK.TabIndex = 80;
            this.lblSK.Text = "SK";
            this.lblSK.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblMB
            // 
            this.lblMB.Location = new System.Drawing.Point(33, 143);
            this.lblMB.Name = "lblMB";
            this.lblMB.Size = new System.Drawing.Size(33, 11);
            this.lblMB.TabIndex = 79;
            this.lblMB.Text = "MB";
            this.lblMB.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblON
            // 
            this.lblON.Location = new System.Drawing.Point(2, 143);
            this.lblON.Name = "lblON";
            this.lblON.Size = new System.Drawing.Size(33, 11);
            this.lblON.TabIndex = 78;
            this.lblON.Text = "ON";
            this.lblON.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblQC
            // 
            this.lblQC.Location = new System.Drawing.Point(64, 128);
            this.lblQC.Name = "lblQC";
            this.lblQC.Size = new System.Drawing.Size(33, 11);
            this.lblQC.TabIndex = 77;
            this.lblQC.Text = "QC";
            this.lblQC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblPEI
            // 
            this.lblPEI.Location = new System.Drawing.Point(33, 128);
            this.lblPEI.Name = "lblPEI";
            this.lblPEI.Size = new System.Drawing.Size(33, 11);
            this.lblPEI.TabIndex = 76;
            this.lblPEI.Text = "PEI";
            this.lblPEI.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblNS
            // 
            this.lblNS.Location = new System.Drawing.Point(2, 128);
            this.lblNS.Name = "lblNS";
            this.lblNS.Size = new System.Drawing.Size(33, 11);
            this.lblNS.TabIndex = 75;
            this.lblNS.Text = "NS";
            this.lblNS.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblNB
            // 
            this.lblNB.Location = new System.Drawing.Point(64, 113);
            this.lblNB.Name = "lblNB";
            this.lblNB.Size = new System.Drawing.Size(33, 11);
            this.lblNB.TabIndex = 74;
            this.lblNB.Text = "NB";
            this.lblNB.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblLB
            // 
            this.lblLB.Location = new System.Drawing.Point(33, 113);
            this.lblLB.Name = "lblLB";
            this.lblLB.Size = new System.Drawing.Size(33, 11);
            this.lblLB.TabIndex = 73;
            this.lblLB.Text = "LB";
            this.lblLB.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblNF
            // 
            this.lblNF.Location = new System.Drawing.Point(2, 113);
            this.lblNF.Name = "lblNF";
            this.lblNF.Size = new System.Drawing.Size(33, 11);
            this.lblNF.TabIndex = 72;
            this.lblNF.Text = "NF";
            this.lblNF.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblSD
            // 
            this.lblSD.Location = new System.Drawing.Point(64, 66);
            this.lblSD.Name = "lblSD";
            this.lblSD.Size = new System.Drawing.Size(33, 11);
            this.lblSD.TabIndex = 71;
            this.lblSD.Text = "SD";
            this.lblSD.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblNE
            // 
            this.lblNE.Location = new System.Drawing.Point(2, 66);
            this.lblNE.Name = "lblNE";
            this.lblNE.Size = new System.Drawing.Size(33, 11);
            this.lblNE.TabIndex = 69;
            this.lblNE.Text = "NE";
            this.lblNE.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblND
            // 
            this.lblND.Location = new System.Drawing.Point(64, 51);
            this.lblND.Name = "lblND";
            this.lblND.Size = new System.Drawing.Size(33, 11);
            this.lblND.TabIndex = 68;
            this.lblND.Text = "ND";
            this.lblND.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblMO
            // 
            this.lblMO.Location = new System.Drawing.Point(33, 51);
            this.lblMO.Name = "lblMO";
            this.lblMO.Size = new System.Drawing.Size(33, 11);
            this.lblMO.TabIndex = 67;
            this.lblMO.Text = "MO";
            this.lblMO.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblMN
            // 
            this.lblMN.Location = new System.Drawing.Point(2, 51);
            this.lblMN.Name = "lblMN";
            this.lblMN.Size = new System.Drawing.Size(33, 11);
            this.lblMN.TabIndex = 66;
            this.lblMN.Text = "MN";
            this.lblMN.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblKS
            // 
            this.lblKS.Location = new System.Drawing.Point(64, 36);
            this.lblKS.Name = "lblKS";
            this.lblKS.Size = new System.Drawing.Size(33, 11);
            this.lblKS.TabIndex = 65;
            this.lblKS.Text = "KS";
            this.lblKS.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblIA
            // 
            this.lblIA.Location = new System.Drawing.Point(33, 36);
            this.lblIA.Name = "lblIA";
            this.lblIA.Size = new System.Drawing.Size(33, 11);
            this.lblIA.TabIndex = 64;
            this.lblIA.Text = "IA";
            this.lblIA.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblCO
            // 
            this.lblCO.Location = new System.Drawing.Point(2, 36);
            this.lblCO.Name = "lblCO";
            this.lblCO.Size = new System.Drawing.Size(33, 11);
            this.lblCO.TabIndex = 63;
            this.lblCO.Text = "CO";
            this.lblCO.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel12
            // 
            this.panel12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel12.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel12.Controls.Add(this.label12);
            this.panel12.Location = new System.Drawing.Point(7, 89);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(83, 22);
            this.panel12.TabIndex = 55;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.Location = new System.Drawing.Point(1, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 17);
            this.label12.TabIndex = 0;
            this.label12.Text = "Canada";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel11
            // 
            this.panel11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel11.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel11.Controls.Add(this.label10);
            this.panel11.Location = new System.Drawing.Point(7, 12);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(83, 22);
            this.panel11.TabIndex = 54;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.Location = new System.Drawing.Point(1, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 17);
            this.label10.TabIndex = 0;
            this.label10.Text = "0";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.lblWI);
            this.groupBox6.Controls.Add(this.lblIN);
            this.groupBox6.Controls.Add(this.lblIL);
            this.groupBox6.Controls.Add(this.panel10);
            this.groupBox6.Controls.Add(this.lblWV);
            this.groupBox6.Controls.Add(this.lblOH);
            this.groupBox6.Controls.Add(this.lblMI);
            this.groupBox6.Controls.Add(this.panel9);
            this.groupBox6.Controls.Add(this.lblWY);
            this.groupBox6.Controls.Add(this.lblWA);
            this.groupBox6.Controls.Add(this.lblUT);
            this.groupBox6.Controls.Add(this.lblOR);
            this.groupBox6.Controls.Add(this.lblAK);
            this.groupBox6.Controls.Add(this.lblNV);
            this.groupBox6.Controls.Add(this.lblMT);
            this.groupBox6.Controls.Add(this.lblID);
            this.groupBox6.Controls.Add(this.lblAZ);
            this.groupBox6.Controls.Add(this.panel8);
            this.groupBox6.Location = new System.Drawing.Point(197, 13);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(97, 223);
            this.groupBox6.TabIndex = 55;
            this.groupBox6.TabStop = false;
            // 
            // lblWI
            // 
            this.lblWI.Location = new System.Drawing.Point(64, 160);
            this.lblWI.Name = "lblWI";
            this.lblWI.Size = new System.Drawing.Size(33, 11);
            this.lblWI.TabIndex = 70;
            this.lblWI.Text = "WI";
            this.lblWI.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblIN
            // 
            this.lblIN.Location = new System.Drawing.Point(33, 160);
            this.lblIN.Name = "lblIN";
            this.lblIN.Size = new System.Drawing.Size(33, 11);
            this.lblIN.TabIndex = 69;
            this.lblIN.Text = "IN";
            this.lblIN.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblIL
            // 
            this.lblIL.Location = new System.Drawing.Point(2, 160);
            this.lblIL.Name = "lblIL";
            this.lblIL.Size = new System.Drawing.Size(33, 11);
            this.lblIL.TabIndex = 68;
            this.lblIL.Text = "IL";
            this.lblIL.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel10
            // 
            this.panel10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel10.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel10.Controls.Add(this.label4);
            this.panel10.Location = new System.Drawing.Point(7, 136);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(83, 22);
            this.panel10.TabIndex = 67;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.Location = new System.Drawing.Point(1, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "9";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWV
            // 
            this.lblWV.Location = new System.Drawing.Point(64, 113);
            this.lblWV.Name = "lblWV";
            this.lblWV.Size = new System.Drawing.Size(33, 11);
            this.lblWV.TabIndex = 66;
            this.lblWV.Text = "WV";
            this.lblWV.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblOH
            // 
            this.lblOH.Location = new System.Drawing.Point(33, 113);
            this.lblOH.Name = "lblOH";
            this.lblOH.Size = new System.Drawing.Size(33, 11);
            this.lblOH.TabIndex = 65;
            this.lblOH.Text = "OH";
            this.lblOH.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblMI
            // 
            this.lblMI.Location = new System.Drawing.Point(2, 113);
            this.lblMI.Name = "lblMI";
            this.lblMI.Size = new System.Drawing.Size(33, 11);
            this.lblMI.TabIndex = 64;
            this.lblMI.Text = "MI";
            this.lblMI.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel9
            // 
            this.panel9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel9.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel9.Controls.Add(this.label15);
            this.panel9.Location = new System.Drawing.Point(7, 89);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(83, 22);
            this.panel9.TabIndex = 63;
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.Location = new System.Drawing.Point(1, 3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 17);
            this.label15.TabIndex = 0;
            this.label15.Text = "8";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWY
            // 
            this.lblWY.Location = new System.Drawing.Point(64, 66);
            this.lblWY.Name = "lblWY";
            this.lblWY.Size = new System.Drawing.Size(33, 11);
            this.lblWY.TabIndex = 62;
            this.lblWY.Text = "WY";
            this.lblWY.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblWA
            // 
            this.lblWA.Location = new System.Drawing.Point(33, 66);
            this.lblWA.Name = "lblWA";
            this.lblWA.Size = new System.Drawing.Size(33, 11);
            this.lblWA.TabIndex = 61;
            this.lblWA.Text = "WA";
            this.lblWA.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblUT
            // 
            this.lblUT.Location = new System.Drawing.Point(2, 66);
            this.lblUT.Name = "lblUT";
            this.lblUT.Size = new System.Drawing.Size(33, 11);
            this.lblUT.TabIndex = 60;
            this.lblUT.Text = "UT";
            this.lblUT.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblOR
            // 
            this.lblOR.Location = new System.Drawing.Point(64, 51);
            this.lblOR.Name = "lblOR";
            this.lblOR.Size = new System.Drawing.Size(33, 11);
            this.lblOR.TabIndex = 59;
            this.lblOR.Text = "OR";
            this.lblOR.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblAK
            // 
            this.lblAK.Location = new System.Drawing.Point(33, 51);
            this.lblAK.Name = "lblAK";
            this.lblAK.Size = new System.Drawing.Size(33, 11);
            this.lblAK.TabIndex = 58;
            this.lblAK.Text = "AK";
            this.lblAK.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblNV
            // 
            this.lblNV.Location = new System.Drawing.Point(2, 51);
            this.lblNV.Name = "lblNV";
            this.lblNV.Size = new System.Drawing.Size(33, 11);
            this.lblNV.TabIndex = 57;
            this.lblNV.Text = "NV";
            this.lblNV.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblMT
            // 
            this.lblMT.Location = new System.Drawing.Point(64, 36);
            this.lblMT.Name = "lblMT";
            this.lblMT.Size = new System.Drawing.Size(33, 11);
            this.lblMT.TabIndex = 56;
            this.lblMT.Text = "MT";
            this.lblMT.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblID
            // 
            this.lblID.Location = new System.Drawing.Point(33, 36);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(33, 11);
            this.lblID.TabIndex = 55;
            this.lblID.Text = "ID";
            this.lblID.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblAZ
            // 
            this.lblAZ.Location = new System.Drawing.Point(2, 36);
            this.lblAZ.Name = "lblAZ";
            this.lblAZ.Size = new System.Drawing.Size(33, 11);
            this.lblAZ.TabIndex = 54;
            this.lblAZ.Text = "AZ";
            this.lblAZ.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel8
            // 
            this.panel8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel8.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel8.Controls.Add(this.label20);
            this.panel8.Location = new System.Drawing.Point(7, 12);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(83, 22);
            this.panel8.TabIndex = 53;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.Location = new System.Drawing.Point(1, 3);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(77, 17);
            this.label20.TabIndex = 0;
            this.label20.Text = "7";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lblHI);
            this.groupBox5.Controls.Add(this.lblCA);
            this.groupBox5.Controls.Add(this.panel7);
            this.groupBox5.Controls.Add(this.lblTX);
            this.groupBox5.Controls.Add(this.lblOK);
            this.groupBox5.Controls.Add(this.lblNM);
            this.groupBox5.Controls.Add(this.lblMS);
            this.groupBox5.Controls.Add(this.lblLA);
            this.groupBox5.Controls.Add(this.lblAR);
            this.groupBox5.Controls.Add(this.panel6);
            this.groupBox5.Controls.Add(this.lblVA);
            this.groupBox5.Controls.Add(this.lblTN);
            this.groupBox5.Controls.Add(this.lblSC);
            this.groupBox5.Controls.Add(this.lblNC);
            this.groupBox5.Controls.Add(this.lblKY);
            this.groupBox5.Controls.Add(this.lblGA);
            this.groupBox5.Controls.Add(this.lblFL);
            this.groupBox5.Controls.Add(this.lblAL);
            this.groupBox5.Controls.Add(this.panel5);
            this.groupBox5.Location = new System.Drawing.Point(101, 13);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(97, 223);
            this.groupBox5.TabIndex = 54;
            this.groupBox5.TabStop = false;
            // 
            // lblHI
            // 
            this.lblHI.Location = new System.Drawing.Point(64, 176);
            this.lblHI.Name = "lblHI";
            this.lblHI.Size = new System.Drawing.Size(33, 11);
            this.lblHI.TabIndex = 57;
            this.lblHI.Text = "HI";
            this.lblHI.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblCA
            // 
            this.lblCA.Location = new System.Drawing.Point(2, 176);
            this.lblCA.Name = "lblCA";
            this.lblCA.Size = new System.Drawing.Size(33, 11);
            this.lblCA.TabIndex = 56;
            this.lblCA.Text = "CA";
            this.lblCA.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel7
            // 
            this.panel7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel7.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel7.Controls.Add(this.label13);
            this.panel7.Location = new System.Drawing.Point(7, 152);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(83, 22);
            this.panel7.TabIndex = 55;
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.Location = new System.Drawing.Point(1, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 17);
            this.label13.TabIndex = 0;
            this.label13.Text = "6";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTX
            // 
            this.lblTX.Location = new System.Drawing.Point(64, 129);
            this.lblTX.Name = "lblTX";
            this.lblTX.Size = new System.Drawing.Size(33, 11);
            this.lblTX.TabIndex = 54;
            this.lblTX.Text = "TX";
            this.lblTX.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblOK
            // 
            this.lblOK.Location = new System.Drawing.Point(33, 129);
            this.lblOK.Name = "lblOK";
            this.lblOK.Size = new System.Drawing.Size(33, 11);
            this.lblOK.TabIndex = 53;
            this.lblOK.Text = "OK";
            this.lblOK.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblNM
            // 
            this.lblNM.Location = new System.Drawing.Point(2, 129);
            this.lblNM.Name = "lblNM";
            this.lblNM.Size = new System.Drawing.Size(33, 11);
            this.lblNM.TabIndex = 52;
            this.lblNM.Text = "NM";
            this.lblNM.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblMS
            // 
            this.lblMS.Location = new System.Drawing.Point(64, 112);
            this.lblMS.Name = "lblMS";
            this.lblMS.Size = new System.Drawing.Size(33, 11);
            this.lblMS.TabIndex = 51;
            this.lblMS.Text = "MS";
            this.lblMS.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblLA
            // 
            this.lblLA.Location = new System.Drawing.Point(33, 113);
            this.lblLA.Name = "lblLA";
            this.lblLA.Size = new System.Drawing.Size(33, 11);
            this.lblLA.TabIndex = 50;
            this.lblLA.Text = "LA";
            this.lblLA.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblAR
            // 
            this.lblAR.Location = new System.Drawing.Point(2, 113);
            this.lblAR.Name = "lblAR";
            this.lblAR.Size = new System.Drawing.Size(33, 11);
            this.lblAR.TabIndex = 49;
            this.lblAR.Text = "AR";
            this.lblAR.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel6.Controls.Add(this.label18);
            this.panel6.Location = new System.Drawing.Point(7, 89);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(83, 22);
            this.panel6.TabIndex = 48;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.Location = new System.Drawing.Point(1, 3);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(77, 17);
            this.label18.TabIndex = 0;
            this.label18.Text = "5";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVA
            // 
            this.lblVA.Location = new System.Drawing.Point(64, 66);
            this.lblVA.Name = "lblVA";
            this.lblVA.Size = new System.Drawing.Size(33, 11);
            this.lblVA.TabIndex = 47;
            this.lblVA.Text = "VA";
            this.lblVA.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblTN
            // 
            this.lblTN.Location = new System.Drawing.Point(2, 66);
            this.lblTN.Name = "lblTN";
            this.lblTN.Size = new System.Drawing.Size(33, 11);
            this.lblTN.TabIndex = 46;
            this.lblTN.Text = "TN";
            this.lblTN.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblSC
            // 
            this.lblSC.Location = new System.Drawing.Point(64, 51);
            this.lblSC.Name = "lblSC";
            this.lblSC.Size = new System.Drawing.Size(33, 11);
            this.lblSC.TabIndex = 45;
            this.lblSC.Text = "SC";
            this.lblSC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblNC
            // 
            this.lblNC.Location = new System.Drawing.Point(33, 51);
            this.lblNC.Name = "lblNC";
            this.lblNC.Size = new System.Drawing.Size(33, 11);
            this.lblNC.TabIndex = 44;
            this.lblNC.Text = "NC";
            this.lblNC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblKY
            // 
            this.lblKY.Location = new System.Drawing.Point(2, 51);
            this.lblKY.Name = "lblKY";
            this.lblKY.Size = new System.Drawing.Size(33, 11);
            this.lblKY.TabIndex = 43;
            this.lblKY.Text = "KY";
            this.lblKY.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblGA
            // 
            this.lblGA.Location = new System.Drawing.Point(64, 36);
            this.lblGA.Name = "lblGA";
            this.lblGA.Size = new System.Drawing.Size(33, 11);
            this.lblGA.TabIndex = 42;
            this.lblGA.Text = "GA";
            this.lblGA.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblFL
            // 
            this.lblFL.Location = new System.Drawing.Point(33, 36);
            this.lblFL.Name = "lblFL";
            this.lblFL.Size = new System.Drawing.Size(33, 11);
            this.lblFL.TabIndex = 41;
            this.lblFL.Text = "FL";
            this.lblFL.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblAL
            // 
            this.lblAL.Location = new System.Drawing.Point(2, 36);
            this.lblAL.Name = "lblAL";
            this.lblAL.Size = new System.Drawing.Size(33, 11);
            this.lblAL.TabIndex = 40;
            this.lblAL.Text = "AL";
            this.lblAL.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel5.Controls.Add(this.label14);
            this.panel5.Location = new System.Drawing.Point(7, 12);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(83, 22);
            this.panel5.TabIndex = 39;
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.Location = new System.Drawing.Point(1, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 17);
            this.label14.TabIndex = 0;
            this.label14.Text = "4";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lblDC);
            this.groupBox4.Controls.Add(this.lblPA);
            this.groupBox4.Controls.Add(this.lblMD);
            this.groupBox4.Controls.Add(this.lblDE);
            this.groupBox4.Controls.Add(this.panel4);
            this.groupBox4.Controls.Add(this.lblNJ);
            this.groupBox4.Controls.Add(this.lblNY);
            this.groupBox4.Controls.Add(this.panel3);
            this.groupBox4.Controls.Add(this.lblVT);
            this.groupBox4.Controls.Add(this.lbRI);
            this.groupBox4.Controls.Add(this.lblNH);
            this.groupBox4.Controls.Add(this.lblME);
            this.groupBox4.Controls.Add(this.lblMA);
            this.groupBox4.Controls.Add(this.lblCT);
            this.groupBox4.Controls.Add(this.panel2);
            this.groupBox4.Controls.Add(this.lblR3);
            this.groupBox4.Controls.Add(this.lblR2);
            this.groupBox4.Controls.Add(this.lblR1);
            this.groupBox4.Controls.Add(this.panel1);
            this.groupBox4.Location = new System.Drawing.Point(6, 13);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(97, 223);
            this.groupBox4.TabIndex = 53;
            this.groupBox4.TabStop = false;
            // 
            // lblDC
            // 
            this.lblDC.Location = new System.Drawing.Point(64, 207);
            this.lblDC.Name = "lblDC";
            this.lblDC.Size = new System.Drawing.Size(33, 11);
            this.lblDC.TabIndex = 37;
            this.lblDC.Text = "DC";
            this.lblDC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblPA
            // 
            this.lblPA.Location = new System.Drawing.Point(2, 207);
            this.lblPA.Name = "lblPA";
            this.lblPA.Size = new System.Drawing.Size(33, 11);
            this.lblPA.TabIndex = 36;
            this.lblPA.Text = "PA";
            this.lblPA.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblMD
            // 
            this.lblMD.Location = new System.Drawing.Point(64, 192);
            this.lblMD.Name = "lblMD";
            this.lblMD.Size = new System.Drawing.Size(33, 11);
            this.lblMD.TabIndex = 35;
            this.lblMD.Text = "MD";
            this.lblMD.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblDE
            // 
            this.lblDE.Location = new System.Drawing.Point(2, 192);
            this.lblDE.Name = "lblDE";
            this.lblDE.Size = new System.Drawing.Size(33, 11);
            this.lblDE.TabIndex = 34;
            this.lblDE.Text = "DE";
            this.lblDE.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel4.Controls.Add(this.label11);
            this.panel4.Location = new System.Drawing.Point(7, 168);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(83, 22);
            this.panel4.TabIndex = 33;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.Location = new System.Drawing.Point(1, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 17);
            this.label11.TabIndex = 0;
            this.label11.Text = "3";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNJ
            // 
            this.lblNJ.Location = new System.Drawing.Point(64, 145);
            this.lblNJ.Name = "lblNJ";
            this.lblNJ.Size = new System.Drawing.Size(33, 11);
            this.lblNJ.TabIndex = 32;
            this.lblNJ.Text = "NJ";
            this.lblNJ.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblNY
            // 
            this.lblNY.Location = new System.Drawing.Point(2, 145);
            this.lblNY.Name = "lblNY";
            this.lblNY.Size = new System.Drawing.Size(33, 11);
            this.lblNY.TabIndex = 31;
            this.lblNY.Text = "NY";
            this.lblNY.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel3.Controls.Add(this.label16);
            this.panel3.Location = new System.Drawing.Point(7, 121);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(83, 22);
            this.panel3.TabIndex = 30;
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.Location = new System.Drawing.Point(1, 3);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 17);
            this.label16.TabIndex = 0;
            this.label16.Text = "2";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVT
            // 
            this.lblVT.Location = new System.Drawing.Point(64, 98);
            this.lblVT.Name = "lblVT";
            this.lblVT.Size = new System.Drawing.Size(33, 11);
            this.lblVT.TabIndex = 29;
            this.lblVT.Text = "VT";
            this.lblVT.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbRI
            // 
            this.lbRI.Location = new System.Drawing.Point(33, 98);
            this.lbRI.Name = "lbRI";
            this.lbRI.Size = new System.Drawing.Size(33, 11);
            this.lbRI.TabIndex = 28;
            this.lbRI.Text = "RI";
            this.lbRI.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblNH
            // 
            this.lblNH.Location = new System.Drawing.Point(2, 98);
            this.lblNH.Name = "lblNH";
            this.lblNH.Size = new System.Drawing.Size(33, 11);
            this.lblNH.TabIndex = 27;
            this.lblNH.Text = "NH";
            this.lblNH.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblME
            // 
            this.lblME.Location = new System.Drawing.Point(64, 83);
            this.lblME.Name = "lblME";
            this.lblME.Size = new System.Drawing.Size(33, 11);
            this.lblME.TabIndex = 26;
            this.lblME.Text = "ME";
            this.lblME.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblMA
            // 
            this.lblMA.Location = new System.Drawing.Point(33, 83);
            this.lblMA.Name = "lblMA";
            this.lblMA.Size = new System.Drawing.Size(33, 11);
            this.lblMA.TabIndex = 25;
            this.lblMA.Text = "MA";
            this.lblMA.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblCT
            // 
            this.lblCT.Location = new System.Drawing.Point(2, 83);
            this.lblCT.Name = "lblCT";
            this.lblCT.Size = new System.Drawing.Size(33, 11);
            this.lblCT.TabIndex = 24;
            this.lblCT.Text = "CT";
            this.lblCT.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(7, 59);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(83, 22);
            this.panel2.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.Location = new System.Drawing.Point(1, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 17);
            this.label9.TabIndex = 0;
            this.label9.Text = "1";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblR3
            // 
            this.lblR3.Location = new System.Drawing.Point(64, 36);
            this.lblR3.Name = "lblR3";
            this.lblR3.Size = new System.Drawing.Size(33, 11);
            this.lblR3.TabIndex = 22;
            this.lblR3.Text = "R3";
            this.lblR3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblR2
            // 
            this.lblR2.Location = new System.Drawing.Point(33, 36);
            this.lblR2.Name = "lblR2";
            this.lblR2.Size = new System.Drawing.Size(33, 11);
            this.lblR2.TabIndex = 21;
            this.lblR2.Text = "R2";
            this.lblR2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblR1
            // 
            this.lblR1.Location = new System.Drawing.Point(2, 36);
            this.lblR1.Name = "lblR1";
            this.lblR1.Size = new System.Drawing.Size(33, 11);
            this.lblR1.TabIndex = 20;
            this.lblR1.Text = "R1";
            this.lblR1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(7, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(83, 22);
            this.panel1.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Location = new System.Drawing.Point(1, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Region";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 431);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(59, 13);
            this.label19.TabIndex = 12;
            this.label19.Text = "Log Name:";
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(73, 428);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(91, 21);
            this.comboBox1.TabIndex = 13;
            // 
            // btnOnOff
            // 
            this.btnOnOff.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnOnOff.Location = new System.Drawing.Point(180, 428);
            this.btnOnOff.Name = "btnOnOff";
            this.btnOnOff.Size = new System.Drawing.Size(75, 23);
            this.btnOnOff.TabIndex = 14;
            this.btnOnOff.Text = "On";
            this.btnOnOff.UseVisualStyleBackColor = true;
            this.btnOnOff.Click += new System.EventHandler(this.btnOnOff_Click);
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(263, 431);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(34, 13);
            this.label21.TabIndex = 15;
            this.label21.Text = "Total:";
            // 
            // groupBox9
            // 
            this.groupBox9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox9.Controls.Add(this.groupBox2);
            this.groupBox9.Controls.Add(this.groupBox3);
            this.groupBox9.Controls.Add(this.groupBox1);
            this.groupBox9.Location = new System.Drawing.Point(304, 7);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(510, 414);
            this.groupBox9.TabIndex = 16;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Scoring";
            // 
            // groupBox10
            // 
            this.groupBox10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox10.Controls.Add(this.panel18);
            this.groupBox10.Controls.Add(this.btnClear);
            this.groupBox10.Controls.Add(this.tbComment);
            this.groupBox10.Controls.Add(this.btnSaveUpdate);
            this.groupBox10.Controls.Add(this.button1);
            this.groupBox10.Controls.Add(this.panel17);
            this.groupBox10.Controls.Add(this.panel16);
            this.groupBox10.Controls.Add(this.panel15);
            this.groupBox10.Controls.Add(this.panel14);
            this.groupBox10.Controls.Add(this.cmbState);
            this.groupBox10.Controls.Add(this.tbRSTRcvd);
            this.groupBox10.Controls.Add(this.tbRSTSent);
            this.groupBox10.Controls.Add(this.tbCall);
            this.groupBox10.Location = new System.Drawing.Point(12, 8);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(286, 150);
            this.groupBox10.TabIndex = 17;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "QSO";
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel18.Controls.Add(this.label25);
            this.panel18.Location = new System.Drawing.Point(13, 121);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(74, 21);
            this.panel18.TabIndex = 16;
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(1, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(66, 21);
            this.label25.TabIndex = 7;
            this.label25.Text = "Comment";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClear.Location = new System.Drawing.Point(205, 45);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 15;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // tbComment
            // 
            this.tbComment.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbComment.Location = new System.Drawing.Point(93, 121);
            this.tbComment.Name = "tbComment";
            this.tbComment.Size = new System.Drawing.Size(187, 20);
            this.tbComment.TabIndex = 14;
            // 
            // btnSaveUpdate
            // 
            this.btnSaveUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveUpdate.Location = new System.Drawing.Point(205, 16);
            this.btnSaveUpdate.Name = "btnSaveUpdate";
            this.btnSaveUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnSaveUpdate.TabIndex = 13;
            this.btnSaveUpdate.Text = "Save/Update";
            this.btnSaveUpdate.UseVisualStyleBackColor = true;
            this.btnSaveUpdate.Click += new System.EventHandler(this.btnSaveUpdate_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(178, 16);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(15, 20);
            this.button1.TabIndex = 12;
            this.button1.Text = "?";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel17.Controls.Add(this.label24);
            this.panel17.Location = new System.Drawing.Point(13, 68);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(74, 21);
            this.panel17.TabIndex = 11;
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(1, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(66, 21);
            this.label24.TabIndex = 7;
            this.label24.Text = "RS(T) Rcvd";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel16.Controls.Add(this.label23);
            this.panel16.Location = new System.Drawing.Point(13, 42);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(74, 21);
            this.panel16.TabIndex = 10;
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(1, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(66, 21);
            this.label23.TabIndex = 7;
            this.label23.Text = "RS(T) Sent";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel15.Controls.Add(this.label27);
            this.panel15.Location = new System.Drawing.Point(13, 16);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(74, 21);
            this.panel15.TabIndex = 9;
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(1, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(66, 21);
            this.label27.TabIndex = 7;
            this.label27.Text = "Call";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel14.Controls.Add(this.label26);
            this.panel14.Location = new System.Drawing.Point(13, 94);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(74, 21);
            this.panel14.TabIndex = 8;
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(1, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(66, 21);
            this.label26.TabIndex = 7;
            this.label26.Text = "State";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmbState
            // 
            this.cmbState.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbState.FormattingEnabled = true;
            this.cmbState.Location = new System.Drawing.Point(93, 94);
            this.cmbState.Name = "cmbState";
            this.cmbState.Size = new System.Drawing.Size(108, 21);
            this.cmbState.TabIndex = 6;
            // 
            // tbRSTRcvd
            // 
            this.tbRSTRcvd.Location = new System.Drawing.Point(93, 68);
            this.tbRSTRcvd.Mask = "999";
            this.tbRSTRcvd.Name = "tbRSTRcvd";
            this.tbRSTRcvd.Size = new System.Drawing.Size(43, 20);
            this.tbRSTRcvd.TabIndex = 5;
            // 
            // tbRSTSent
            // 
            this.tbRSTSent.Location = new System.Drawing.Point(93, 42);
            this.tbRSTSent.Mask = "999";
            this.tbRSTSent.Name = "tbRSTSent";
            this.tbRSTSent.Size = new System.Drawing.Size(43, 20);
            this.tbRSTSent.TabIndex = 4;
            // 
            // tbCall
            // 
            this.tbCall.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbCall.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbCall.Location = new System.Drawing.Point(93, 16);
            this.tbCall.Name = "tbCall";
            this.tbCall.Size = new System.Drawing.Size(86, 20);
            this.tbCall.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            this.dataGridView1.Location = new System.Drawing.Point(12, 189);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(286, 230);
            this.dataGridView1.TabIndex = 18;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editToolStripMenuItem,
            this.deleteToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(108, 48);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.editToolStripMenuItem.Text = "Edit";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(10, 173);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(25, 13);
            this.label22.TabIndex = 19;
            this.label22.Text = "Log";
            // 
            // tbTotalTimeOn
            // 
            this.tbTotalTimeOn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbTotalTimeOn.Location = new System.Drawing.Point(301, 428);
            this.tbTotalTimeOn.Name = "tbTotalTimeOn";
            this.tbTotalTimeOn.ReadOnly = true;
            this.tbTotalTimeOn.Size = new System.Drawing.Size(50, 20);
            this.tbTotalTimeOn.TabIndex = 20;
            this.tbTotalTimeOn.Text = "00:00:00";
            // 
            // label28
            // 
            this.label28.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(361, 431);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(70, 13);
            this.label28.TabIndex = 21;
            this.label28.Text = "This Session:";
            // 
            // tbSessionTimeOn
            // 
            this.tbSessionTimeOn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbSessionTimeOn.Location = new System.Drawing.Point(430, 428);
            this.tbSessionTimeOn.Name = "tbSessionTimeOn";
            this.tbSessionTimeOn.ReadOnly = true;
            this.tbSessionTimeOn.Size = new System.Drawing.Size(50, 20);
            this.tbSessionTimeOn.TabIndex = 22;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(512, 432);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(37, 13);
            this.label29.TabIndex = 23;
            this.label29.Text = "Mode:";
            // 
            // cmbMode
            // 
            this.cmbMode.FormattingEnabled = true;
            this.cmbMode.Items.AddRange(new object[] {
            "CW",
            "Phone"});
            this.cmbMode.Location = new System.Drawing.Point(556, 431);
            this.cmbMode.Name = "cmbMode";
            this.cmbMode.Size = new System.Drawing.Size(82, 21);
            this.cmbMode.TabIndex = 24;
            // 
            // frmContestARRL10M
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 459);
            this.ControlBox = false;
            this.Controls.Add(this.cmbMode);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.tbSessionTimeOn);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.tbTotalTimeOn);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.btnOnOff);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label19);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmContestARRL10M";
            this.Text = "ARRL 10Meter Contest Statistics";
            this.Load += new System.EventHandler(this.frmContestARRL10M_Load);
            this.Shown += new System.EventHandler(this.frmContestARRL10M_Shown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox tbPhoneContacts;
        private System.Windows.Forms.TextBox tbTotalContacts;
        private System.Windows.Forms.Label tbTotalQSOPoints;
        private System.Windows.Forms.Label tbCWContacts;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbTotalScore;
        private System.Windows.Forms.TextBox tbCWMultipliers;
        private System.Windows.Forms.TextBox tbPhoneMultipliers;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbTotalMultipliers;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label lblWI;
        private System.Windows.Forms.Label lblIN;
        private System.Windows.Forms.Label lblIL;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblWV;
        private System.Windows.Forms.Label lblOH;
        private System.Windows.Forms.Label lblMI;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblR1;
        private System.Windows.Forms.Label lblR2;
        private System.Windows.Forms.Label lblR3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblCT;
        private System.Windows.Forms.Label lblMA;
        private System.Windows.Forms.Label lblME;
        private System.Windows.Forms.Label lblNH;
        private System.Windows.Forms.Label lbRI;
        private System.Windows.Forms.Label lblVT;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblNY;
        private System.Windows.Forms.Label lblNJ;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblDE;
        private System.Windows.Forms.Label lblMD;
        private System.Windows.Forms.Label lblPA;
        private System.Windows.Forms.Label lblDC;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lblAL;
        private System.Windows.Forms.Label lblFL;
        private System.Windows.Forms.Label lblGA;
        private System.Windows.Forms.Label lblKY;
        private System.Windows.Forms.Label lblNC;
        private System.Windows.Forms.Label lblSC;
        private System.Windows.Forms.Label lblTN;
        private System.Windows.Forms.Label lblVA;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblAR;
        private System.Windows.Forms.Label lblLA;
        private System.Windows.Forms.Label lblMS;
        private System.Windows.Forms.Label lblNM;
        private System.Windows.Forms.Label lblOK;
        private System.Windows.Forms.Label lblTX;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lblCA;
        private System.Windows.Forms.Label lblHI;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label lblAZ;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lblMT;
        private System.Windows.Forms.Label lblNV;
        private System.Windows.Forms.Label lblAK;
        private System.Windows.Forms.Label lblOR;
        private System.Windows.Forms.Label lblUT;
        private System.Windows.Forms.Label lblWA;
        private System.Windows.Forms.Label lblWY;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblSD;
        private System.Windows.Forms.Label lblNE;
        private System.Windows.Forms.Label lblND;
        private System.Windows.Forms.Label lblMO;
        private System.Windows.Forms.Label lblMN;
        private System.Windows.Forms.Label lblKS;
        private System.Windows.Forms.Label lblIA;
        private System.Windows.Forms.Label lblCO;
        private System.Windows.Forms.Label lblNU;
        private System.Windows.Forms.Label lblYT;
        private System.Windows.Forms.Label lblNWT;
        private System.Windows.Forms.Label lblBC;
        private System.Windows.Forms.Label lblAB;
        private System.Windows.Forms.Label lblSK;
        private System.Windows.Forms.Label lblON;
        private System.Windows.Forms.Label lblQC;
        private System.Windows.Forms.Label lblPEI;
        private System.Windows.Forms.Label lblNS;
        private System.Windows.Forms.Label lblNB;
        private System.Windows.Forms.Label lblLB;
        private System.Windows.Forms.Label lblNF;
        private System.Windows.Forms.Label lblMB;
        private System.Windows.Forms.Label lblZAC;
        private System.Windows.Forms.Label lblYUC;
        private System.Windows.Forms.Label lblVER;
        private System.Windows.Forms.Label lblTLX;
        private System.Windows.Forms.Label lblTAM;
        private System.Windows.Forms.Label lblTAB;
        private System.Windows.Forms.Label lblSON;
        private System.Windows.Forms.Label lblSIN;
        private System.Windows.Forms.Label lblSLP;
        private System.Windows.Forms.Label lblQUI;
        private System.Windows.Forms.Label lblQRO;
        private System.Windows.Forms.Label lblPUE;
        private System.Windows.Forms.Label lblOAX;
        private System.Windows.Forms.Label lblNLE;
        private System.Windows.Forms.Label lblNAY;
        private System.Windows.Forms.Label lblMIC;
        private System.Windows.Forms.Label lblJAL;
        private System.Windows.Forms.Label lblHGO;
        private System.Windows.Forms.Label lblGBO;
        private System.Windows.Forms.Label lblGTO;
        private System.Windows.Forms.Label lblEMX;
        private System.Windows.Forms.Label lblDGO;
        private System.Windows.Forms.Label lblCOL;
        private System.Windows.Forms.Label lblCOA;
        private System.Windows.Forms.Label lblCMX;
        private System.Windows.Forms.Label lblCHH;
        private System.Windows.Forms.Label lblCHI;
        private System.Windows.Forms.Label lblCAM;
        private System.Windows.Forms.Label lblBCS;
        private System.Windows.Forms.Label lblBAC;
        private System.Windows.Forms.Label lblAGS;
        private System.Windows.Forms.Label lblMOR;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnOnOff;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox tbComment;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox cmbState;
        private System.Windows.Forms.MaskedTextBox tbRSTRcvd;
        private System.Windows.Forms.MaskedTextBox tbRSTSent;
        private System.Windows.Forms.TextBox tbTotalTimeOn;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox tbSessionTimeOn;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox cmbMode;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        internal System.Windows.Forms.Button btnSaveUpdate;
        internal System.Windows.Forms.TextBox tbCall;
    }
}